import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestEmpoyeeComponent } from './test-empoyee.component';

describe('TestEmpoyeeComponent', () => {
  let component: TestEmpoyeeComponent;
  let fixture: ComponentFixture<TestEmpoyeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestEmpoyeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestEmpoyeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
