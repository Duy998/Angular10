import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-empoyee',
  templateUrl: './test-empoyee.component.html',
  styleUrls: ['./test-empoyee.component.css']
})
export class TestEmpoyeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
