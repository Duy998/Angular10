import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  employee: Employee = new Employee();
  submitted = false;
  

  constructor(private employeeService: EmployeeService,
    private router: Router) { }

  ngOnInit() {
  }

  newEmployee(): void {
    this.submitted = false;
    this.employee = new Employee();
  }

  checkedUser() {
     
    this.employeeService
    .checkUsers(this.employee).subscribe(data => {
      console.log(data)  
      this.employee = new Employee();
      this.employee = data;
      if(this.employee.roles == "admin"){
        this.gotoList();
      }
      if(this.employee.roles == null){
        this.gotologin();
      }
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.checkedUser();    
  }

  gotoList() {
    this.router.navigate(['/employees']);
  }

  gotologin() {
    this.router.navigate(['/login']);
  }
}
