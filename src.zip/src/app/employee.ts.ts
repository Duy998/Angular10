export class Employee {
    id: number;
    userName: string;
    passWord: string;
    emailId: string;
    active: boolean;
    age : string;
    position : string;
    team : string;
    roles: string;
}