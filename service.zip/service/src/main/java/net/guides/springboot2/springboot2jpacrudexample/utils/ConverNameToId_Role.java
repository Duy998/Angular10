package net.guides.springboot2.springboot2jpacrudexample.utils;

import org.springframework.stereotype.Component;

@Component
public class ConverNameToId_Role {

	public static  Long ConverNameRole(String namerole) {
		if(namerole.equals("QL")) {
			return 1L;
		}
		return 2L;
		
	}
}
