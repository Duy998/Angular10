package net.guides.springboot2.springboot2jpacrudexample.converter;

import org.springframework.stereotype.Component;

import net.guides.springboot2.springboot2jpacrudexample.model.Employee;
import net.guides.springboot2.springboot2jpacrudexample.model.EmployeeConver;
import net.guides.springboot2.springboot2jpacrudexample.model.Role;

@Component
public class EmployeeConverter {

	public EmployeeConver todto(Employee em) {
		EmployeeConver result = new EmployeeConver();
		result.setId(em.getId());
		result.setUserName(em.getUserName());
		result.setPassWord(em.getPassWord());
		result.setEmailId(em.getEmailId());
		result.setAge(em.getAge());
		for (Role a : em.getRoles()) {
			result.setRoles(a.getName());
		}
		result.setTeam(em.getTeam());
		return result;
		
	}
	
}
