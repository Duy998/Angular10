package net.guides.springboot2.springboot2jpacrudexample.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "role")
public class Role extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	@Column
	private String name;
	
	@Column
	private String code;
	
	@ManyToMany(mappedBy = "roles", fetch = FetchType.LAZY)
    private List<Employee> users = new ArrayList<>();
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<Employee> getUsers() {
		return users;
	}
	public void setUsers(List<Employee> users) {
		this.users = users;
	}
	
	
	
	
}
