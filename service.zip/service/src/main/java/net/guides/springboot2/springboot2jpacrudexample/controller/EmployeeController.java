package net.guides.springboot2.springboot2jpacrudexample.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.guides.springboot2.springboot2jpacrudexample.converter.EmployeeConverter;
import net.guides.springboot2.springboot2jpacrudexample.model.Employee;
import net.guides.springboot2.springboot2jpacrudexample.model.EmployeeConver;
import net.guides.springboot2.springboot2jpacrudexample.model.Role;
import net.guides.springboot2.springboot2jpacrudexample.repository.EmployeeRepository;
import net.guides.springboot2.springboot2jpacrudexample.repository.RoleRrepository;
import net.guides.springboot2.springboot2jpacrudexample.utils.ConverNameToId_Role;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class EmployeeController {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private RoleRrepository rolerepository;
	
	@Autowired
	private ConverNameToId_Role converternametonumber_role;
	
	@Autowired
	private EmployeeConverter employeeconverter;

	@GetMapping("/employees")
	public List<EmployeeConver> getAllEmployees() {
		List<EmployeeConver> result = new ArrayList<>();
		List<Employee> em = employeeRepository.findAll();
		for (Employee employee : em) {
			EmployeeConver emconverter = new EmployeeConver();
			emconverter = employeeconverter.todto(employee);
			result.add(emconverter);
		}
		return result;
	}
	
	@GetMapping("/employees/{id}")
	public EmployeeConver getEmployeeById(@PathVariable(value = "id") Long employeeId){
		Employee em = employeeRepository.findOne(employeeId);		
		EmployeeConver result = employeeconverter.todto(em);
		
		return result;
	}

	@PostMapping("/employees")
	public Employee createEmployee(@Valid @RequestBody Employee employee) {
		Employee em = new Employee();
		em.setUserName(employee.getUserName());
		em.setPassWord(employee.getPassWord());
		Role role = new Role();
		role = rolerepository.findOne(converternametonumber_role.ConverNameRole(employee.getPosition()));			
	    em.setRoles(Stream.of(role).collect(Collectors.toList()));
		em.setAge(employee.getAge());
		em.setEmailId(employee.getEmailId());
		em.setTeam(employee.getTeam());
		return employeeRepository.save(em);
	}

	@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "id") Long employeeId,
			 @RequestBody Employee employeeDetails) {
		Employee employee = employeeRepository.findOne(employeeId);	

		employee.setEmailId(employeeDetails.getEmailId());
		employee.setUserName(employeeDetails.getUserName());
		employee.setPassWord(employeeDetails.getPassWord());
		final Employee updatedEmployee = employeeRepository.save(employee);
		return ResponseEntity.ok(updatedEmployee);
	}


	@DeleteMapping("/employees/{id}")
	public Map<String, Boolean> deleteEmployee(@PathVariable(value = "id") Long employeeId)
			{
		Employee employee = employeeRepository.findOne(employeeId);
		employeeRepository.delete(employee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
	
	
}
