package net.guides.springboot2.springboot2jpacrudexample.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.guides.springboot2.springboot2jpacrudexample.model.Employee;
import net.guides.springboot2.springboot2jpacrudexample.model.EmployeeConver;
import net.guides.springboot2.springboot2jpacrudexample.model.Role;
import net.guides.springboot2.springboot2jpacrudexample.repository.EmployeeRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class UsersController {

	@Autowired
	private EmployeeRepository employeeRepository;


	@SuppressWarnings("unused")
	@PostMapping("/users")
	public EmployeeConver checkUsers(@Valid @RequestBody Employee employee) {
		EmployeeConver result = new EmployeeConver();
		Employee em = employeeRepository.findOneByUserNameAndPassWord(employee.getUserName(), employee.getPassWord());
		
		if(em == null ) {
			result.setMessager("sai r");
		}else {			
			for (Role name : em.getRoles()) {
				result.setRoles(name.getName());
			}
		}
		return result;
	
	}
		
		
		
		
	
}
